import { Component, OnInit } from '@angular/core';
import { BankService } from 'src/app/service/bank.service';

@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']
})
export class ShowBalanceComponent implements OnInit {
  searchAccount:number;
  message:string;
  constructor(private service:BankService) { }

  ngOnInit() {
  }
  public showBalance(accountNumber:number) {
    if (accountNumber!=null) {
    this.service.showBalance(accountNumber).subscribe(data=> {
    this.message=' Hello'+data.name+' '+' your Available balance is '+data.balance;
     });}
    }
}
