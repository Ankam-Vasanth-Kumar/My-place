package com.capgemini.BankingSystem.Dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemin.BankingSystem.Bean.Transactions;

public interface IBankingSystemDao {
	public Map<Integer,Transactions> transactlist=new HashMap<>();
    public Map<Integer,Transactions> getAllTransactions();
    public boolean addTransaction(Transactions tran, int transactId);
  
  
}
