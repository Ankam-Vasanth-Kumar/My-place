package com.cg.bank.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bank.dao.BankDaoAccount;
import com.cg.bank.dao.BankDaoCustomer;
import com.cg.bank.dao.BankDaoTransaction;
import com.cg.bank.dto.Account;
import com.cg.bank.dto.Customer;
import com.cg.bank.dto.Transaction;
import com.cg.bank.exception.BankException;

@Service
public class BankServiceImpl implements BankService {
	@Autowired
	private BankDaoCustomer bankCust;
	@Autowired
	private BankDaoAccount bankAcc;
	@Autowired
	private BankDaoTransaction bankTrans;
	

	@Override
	public String addCustomer(Customer customer) throws BankException {
		bankCust.save(customer);
		Random r = new Random();
		int password = r.nextInt((5000-1000)+1)+1000;
        Account account=new Account();
		account.setAccountNo(customer.getCustomerId());
		account.setBalance(customer.getAmount());
		account.setName(customer.getName());
		account.setPassword(password);
		
		bankAcc.save(account);
		return "Customer registered successfully with account no: " + customer.getCustomerId() + "and password: "
				+ account.getPassword();

	}

	@Override
	public String login(Account account) throws BankException {

		if (bankAcc.existsById(account.getAccountNo())) {
			return "Login successfully";

		} else {
			return "Invalid credentials";
		}

	}

	@Override
	public String withdraw(double amount, Account accnt) throws BankException {
		Account account = bankAcc.findById(accnt.getAccountNo()).get();
		if (bankAcc.existsById(accnt.getAccountNo())) {
			double amnt = account.getBalance();
			if (amnt > amount) {
				amnt = amnt - amount;
				account.setBalance(amnt);
				bankAcc.save(account);
				SimpleDateFormat formatter= new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
				Date d = new Date();
				String dt = formatter.format(d);
		        try {
		            d = formatter.parse(dt);
		        } catch (ParseException e) {
		            System.out.println(e.getMessage());
		        }
		        Transaction trans= new Transaction();
				trans.setTransType("withdraw");
				trans.setTransDate(d);
				trans.settoAccountNo(accnt.getAccountNo());
				trans.setfromAccountNo(accnt.getAccountNo());
				trans.setAmount(amount);
				trans.setBalance(amnt);
				bankTrans.save(trans);
				return "Withdrawn successfully";
			}

			else {

				throw new BankException("Insufficient balance");

			}
		} else {
			throw new BankException(" Invalid login");
		}
	}

	@Override
	public Account showBalance(long accountNo) throws BankException {
		
		if (bankAcc.existsById(accountNo)) {
			Account account = bankAcc.findById(accountNo).get();
			return account;
		} else {
			throw new BankException(" Invalid login");
		}
	}

	@Override
	public String depositAmount(long accountNo, Account accnt) throws BankException {
		Account account = bankAcc.findById(accountNo).get();
		if (bankAcc.existsById(accountNo)) {
			double amnt = accnt.getBalance();

			amnt = amnt + account.getBalance();
			account.setBalance(amnt);
			SimpleDateFormat formatter= new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			Date d = new Date();
			String dt = formatter.format(d);
	        try {
	            d = formatter.parse(dt);
	        } catch (ParseException e) {
	            System.out.println(e.getMessage());
	        }
			Transaction trans= new Transaction();
			trans.setTransType("deposit");
			trans.setTransDate(d);
			trans.settoAccountNo(accnt.getAccountNo());
			trans.setfromAccountNo(accnt.getAccountNo());
			trans.setAmount(account.getBalance());
			trans.setBalance(amnt);
			bankTrans.save(trans);
			bankAcc.save(account);
			return "Deposited successfully";
		}

		else {
			throw new BankException(" Invalid login");
		}
	}

	@Override
	public String fundTransfer(double amount, long accountNo, Account accnt) throws BankException {
		Account account = bankAcc.findById(accnt.getAccountNo()).get();
		Account sendAccount = bankAcc.findById(accountNo).get();
		if (bankAcc.existsById(accountNo)) {
			if (account.getBalance() > amount) {
				double amnt = sendAccount.getBalance();
				amnt = amnt + amount;
				sendAccount.setBalance(amnt);
				double amnt1 = account.getBalance();
				amnt1 = amnt1 - amount;
				account.setBalance(amnt1);
				bankAcc.save(account);
				bankAcc.save(sendAccount);
				SimpleDateFormat formatter= new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
				Date d = new Date();
				String dt = formatter.format(d);
		        try {
		            d = formatter.parse(dt);
		        } catch (ParseException e) {
		            System.out.println(e.getMessage());
		        }
				
				
				Transaction trans= new Transaction();
				trans.setTransType("Transaction");
				trans.setTransDate(d);
				trans.settoAccountNo(sendAccount.getAccountNo());
				trans.setfromAccountNo(accnt.getAccountNo());
				trans.setAmount(amount);
				trans.setBalance(amnt1);
				bankTrans.save(trans);
				Transaction trans1= new Transaction();
				trans1.setTransType("Transaction");
				trans1.setTransDate(d);
				trans1.settoAccountNo(accnt.getAccountNo());
				trans1.setfromAccountNo(sendAccount.getAccountNo());
				trans1.setAmount(amount);
				trans1.setBalance(amnt);
				bankTrans.save(trans);
				bankTrans.save(trans1);
				return "Amount transferred successfully";
			} else {

				throw new BankException("Insufficient balance");

			}
		} else {
			throw new BankException(" Invalid login");
		}

	}

	@Override
	public List<Transaction> printTransaction(long accountNo, Account account) throws BankException {
		
		if (bankAcc.existsById(account.getAccountNo())&&(account.getAccountNo()==accountNo)) {
			return bankTrans.printTransaction(accountNo);
		}
		else {
			throw new BankException(" Invalid login");
		}
		
	}

}
