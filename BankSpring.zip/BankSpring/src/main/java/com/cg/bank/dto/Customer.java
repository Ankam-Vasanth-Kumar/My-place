package com.cg.bank.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "BankCustomer")
public class Customer {
	@Id
	@SequenceGenerator(name = "customerIdSeq", sequenceName = "customerIdSeq",initialValue = 2000,allocationSize = 3)
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "customerIdSeq")
	private int customerId;
	private String name;
	private String email;
	private String mobile;
	private String address;
	private double amount;
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(int customerId, String name, String email, String mobile, String address, double amount) {
		super();
		this.customerId = customerId;
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.address = address;
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", name=" + name + ", email=" + email + ", mobile=" + mobile
				+ ", address=" + address + ", amount=" + amount + "]";
	}
	
}
