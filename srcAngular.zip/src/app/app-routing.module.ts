import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddCustomerComponent } from './component/add-customer/add-customer.component';
import { LoginComponent } from './component/login/login.component';
import { ShowComponent } from './component/show/show.component';
import { ShowBalanceComponent } from './component/show-balance/show-balance.component';
import { DepositComponent } from './component/deposit/deposit.component';
import { WithdrawComponent } from './component/withdraw/withdraw.component';
import { WelcomeComponent } from './component/welcome/welcome.component';


const routes: Routes = [
  {path:'',redirectTo:'welcome',pathMatch:'full'},
  { path: 'create', component: AddCustomerComponent },
  {path : 'login', component : LoginComponent},
  {path:'show',component:ShowComponent},
  {path:'balance',component:ShowBalanceComponent},
  {path:'deposit',component:DepositComponent},
  {path:'withdraw',component:WithdrawComponent},
  {path:'welcome',component:WelcomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
