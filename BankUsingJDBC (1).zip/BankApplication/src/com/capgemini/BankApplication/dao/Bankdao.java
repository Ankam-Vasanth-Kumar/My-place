package com.capgemini.BankApplication.dao;

import java.util.HashMap;

import com.capgemini.BankApplication.bean.Account;
import com.capgemini.BankApplication.bean.Transaction;

public interface Bankdao {
static	HashMap<Integer, Transaction>translist=new HashMap<>();
       HashMap<Long, Account>accountsList=new HashMap<>();
       HashMap<String, String>accountcheck=new HashMap<>();
       HashMap<Long, Long>showbalance=new HashMap<>();
       
	boolean addingAccount(Account account);

	HashMap<Long, Account> getDetails();

	HashMap<String, String> getunamePassword();

	void getBalance(long accountNo);

	boolean addtransaction(Transaction transaction, long bal);

	HashMap<Integer, Transaction> getTransaction();

	boolean transferTo(Transaction tran2, long money);

	void deposite(Transaction tran, long bal);

	void withdraw(Transaction tran1, long amount);

}
