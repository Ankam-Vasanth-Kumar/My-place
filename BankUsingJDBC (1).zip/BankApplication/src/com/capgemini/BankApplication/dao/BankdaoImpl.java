package com.capgemini.BankApplication.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import com.capgemini.BankApplication.Utility.DBConnection;
import com.capgemini.BankApplication.bean.Account;
import com.capgemini.BankApplication.bean.Transaction;


public class BankdaoImpl implements Bankdao {
	Connection connection=null;
	PreparedStatement statement=null;

	@Override
	public boolean addingAccount(Account account) {
	   accountsList.put(account.getAccountNo(),account);
	 accountcheck.put(account.getUname(), account.getPassword());
	 showbalance.put(account.getAccountNo(), account.getBalance());
	 
		PreparedStatement statement=null;
		ResultSet resultSet=null;
		int row=-1;
	 try(Connection connection=DBConnection.getConnection();) {
			
			statement=connection.prepareStatement("insert into Accounts values(?,?,?,?,?,?,?)");
			statement.setLong(1, account.getAccountNo());
			statement.setString(2, account.getUname());
			statement.setString(3, account.getPassword());
			statement.setString(4, account.getAddress());
			statement.setString(5, account.getMobileNo());
			statement.setLong(6, account.getAadhrCardNo());
			statement.setLong(7, account.getBalance());
			row=statement.executeUpdate();
			System.out.println(" Account Added");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}	
	 
	 return true;
	}

	@Override
	public HashMap<Long, Account> getDetails() {
		return accountsList;
	}

	@Override
	public HashMap<String, String> getunamePassword() {
	
		return accountcheck;
	}

	@Override
	public void getBalance(long accountNo) {
		try(Connection connection=DBConnection.getConnection();) {
			statement=connection.prepareStatement("select accountNo,name,balance from accounts where ACCOUNTNO=?");
			statement.setLong(1,accountNo);
	ResultSet	rs=statement.executeQuery();
while(rs.next()) {
	System.out.println(rs.getLong(1)+"           "+rs.getString(2)+"                  "+rs.getLong(3));
}
		
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
	}

	@Override
	public boolean addtransaction(Transaction transaction,long bal) {
		PreparedStatement statement=null;
		int row=-1;
		 try(Connection connection=DBConnection.getConnection();) {
			statement=connection.prepareStatement("insert into Transaction values(?,?,?,?,?,?)");
			statement.setInt(1, transaction.getTid());
			statement.setLong(2, transaction.getFromAccountNo() );
			statement.setLong(3, transaction.getToAccountNo()  );
		
			statement.setDate(4, transaction.getDate());
			statement.setString(5, transaction.getTransactionType());
			statement.setLong(6, transaction.getMoney());
		
			row=statement.executeUpdate();
			System.out.println(" Transaction Added");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}	
	
		return true;
	}

	@Override
	public HashMap<Integer, Transaction> getTransaction() {
		return translist;
	}

	@Override
	public boolean transferTo(Transaction tran2, long amount) {
		PreparedStatement statement=null;
		ResultSet resultSet=null;
		int row=-1;
		long prevBal;
try(Connection connection=DBConnection.getConnection();) {
	
	statement =connection.prepareStatement("select balance from accounts  where accountNo=?");
	 statement.setLong(1, tran2.getFromAccountNo());
	 
	ResultSet	rs=statement.executeQuery();
	rs.next();
prevBal=rs.getLong(1);
	if(prevBal>amount)
		amount=prevBal-amount;
	else
		amount=amount-prevBal;
System.out.println("prev bal:"+prevBal);
	
				System.out.println("current bal :"+amount);
				statement =connection.prepareStatement("update accounts set balance=? where accountNo=?");
				statement.setLong(1, amount);
				 statement.setLong(2, tran2.getFromAccountNo());
				 ResultSet	rs1=statement.executeQuery();
	
				 statement =connection.prepareStatement("select balance from accounts  where accountNo=?");
				 statement.setLong(1, tran2.getToAccountNo());
				 
				ResultSet	rs11=statement.executeQuery();
				rs11.next();
				prevBal=rs11.getLong(1);
					
						amount=amount+prevBal;
				System.out.println("prev bal:"+prevBal);
					
								System.out.println("current bal :"+amount);
	
	
			 statement =connection.prepareStatement("update accounts set balance=? where accountNo=?");
			 statement.setLong(1, amount);
			 statement.setLong(2, tran2.getToAccountNo());
			 row=statement.executeUpdate();
			 
			
			System.out.println(" Transferred successfully");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}	
		return false;
	}

	@Override
	public void deposite(Transaction tran, long bal) {
		ResultSet resultSet=null;
		int row=-1;
try(Connection connection=DBConnection.getConnection();) {
	 statement =connection.prepareStatement("select balance from accounts  where accountNo=?");
	 statement.setLong(1, tran.getFromAccountNo());
	 
	ResultSet	rs=statement.executeQuery();
	rs.next();

	
long prevBal=rs.getLong(1);
System.out.println("prev bal:"+prevBal);
	bal=bal+prevBal;
	
				System.out.println("current bal :"+bal);
	
			 statement =connection.prepareStatement("update accounts set balance=? where accountNo=?");
			 statement.setLong(1, bal);
			 statement.setLong(2, tran.getFromAccountNo());
			 row=statement.executeUpdate();
			
		
	} catch (SQLException e) {
	
		e.printStackTrace();
	}

}

	@Override
	public void withdraw(Transaction tran1, long amount) {
		ResultSet resultSet=null;
		int row=-1;
		long balance;
try(Connection connection=DBConnection.getConnection();) {
	 statement =connection.prepareStatement("select balance from accounts  where accountNo=?");
	 statement.setLong(1, tran1.getFromAccountNo());
	 
	ResultSet	rs=statement.executeQuery();
	rs.next();

	System.out.println("amount in withdrawn DAO:"+amount);
long prevBal=rs.getLong(1);
System.out.println("prev bal:"+prevBal);
if(prevBal>amount)
	balance=prevBal-amount;
else
	balance=amount-prevBal;
	
	
				System.out.println("current bal :"+balance);
	
			 statement =connection.prepareStatement("update accounts set balance=? where accountNo=?");
			 statement.setLong(1, balance);
			 statement.setLong(2, tran1.getFromAccountNo());
			 row=statement.executeUpdate();
			
		
	} catch (SQLException e) {
	
		e.printStackTrace();
	}

		
	}
}
