package om.capgemini.BankApplication.UI;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.BankApplication.Exception.BankApplicationException;
import com.capgemini.BankApplication.bean.Account;
import com.capgemini.BankApplication.bean.Transaction;
import com.capgemini.BankApplication.service.BankService;
import com.capgemini.BankApplication.service.BankServiceImpl;
import com.capgemini.BankApplication.Utility.*;


public class UIClass {
	String uname,password,address,mobileNo;
	long aadhrCardNo;
	long bal=0;
	long accountNo=0;
	long amount;
	 long accno=0;
	 static int  Tid=0;
	Scanner scanner=new Scanner(System.in);
	BankService service=new BankServiceImpl();
	Connection connection=null;
	PreparedStatement statement=null;
	
	
	HashMap<String, String> list=new HashMap<>();
	
	HashMap<Long, Long>list2=new HashMap<>();
	
private void Login(long accountNo) throws SQLException {
	
		String name;
		String password2;
		list=service.getUnamePassword();
	
		System.out.println("Enter Name ");
		name=scanner.next();
		System.out.println("Enter Password ");
		password2=scanner.next();
		try(Connection connection=DBConnection.getConnection();) {
			statement=connection.prepareStatement("select name,password from accounts where ACCOUNTNO=?");
			statement.setLong(1,accountNo);
	ResultSet	rs=statement.executeQuery();
while(rs.next()) {
	System.out.println("getting"+rs.getString(1)+"hfjkdhsf    "+rs.getString(2));
}
if(true){
			System.out.println(list.containsValue(password2));
			System.out.println("************************Welcome to Capgemini****************************");
			int choice = 2;
			boolean flag = true;
			String ch = null;
	        do {
			System.out.println("1.ShowBalance             2.Deposit\n 3.WithDraw                 4.MoneyTransfer\n5.PrintTransaction       0.Exit");
			try {
				Scanner scanner1=new Scanner(System.in);
				choice = scanner1.nextInt();

				switch (choice) {
				case 1:
					service.ShowBalance(accountNo);
					
			
					flag=false;
					break;
				
				case 2:
					Tid++;
			      System.out.println("enter money");
			      Scanner scanner3=new Scanner(System.in);
			      amount=scanner3.nextLong();
			     
			      java.util.Date date=new java.util.Date();
					
					java.sql.Date sqlDate=new java.sql.Date(date.getTime());
			      accno=accountNo;
			      Transaction tran=new  Transaction(accountNo,accno,sqlDate,"Credit",amount,Tid);
			     service.deposite(tran,amount);
					 boolean flag1=service.addTransaction(tran,amount);
						if(flag1)
							System.out.println("  Money Deposited");
						else
							System.out.println("unable to create account");
			      
					flag=false;
					break;
				case 3:Tid++;
					   System.out.println("enter money to withdraw");
				      Scanner scanner2=new Scanner(System.in);
				      amount=scanner2.nextLong();
				 
				      java.util.Date date1=new java.util.Date();
						
						java.sql.Date sqlDate1=new java.sql.Date(date1.getTime());
				      accno=accountNo;
				      Transaction tran1=new  Transaction(accountNo,accno,sqlDate1,"Debit",amount,Tid);
				      service.withdraw(tran1,amount);
						 boolean flag11=service.addTransaction(tran1,bal);
							if(flag11)
								System.out.println("  Money Withdrawn Successfully.................");
							else
								System.out.println("unable to create account");
				      
			          flag=false;
						break;
				case 4:Tid++;
				boolean flag2=false;
					System.out.println("enter account No of receiver:\n");
					 Scanner scanner4=new Scanner(System.in);
					 accno=scanner4.nextLong();
					 System.out.println("enetr money");
					 long money=scanner4.nextLong();
					 java.util.Date date11=new java.util.Date();
						
						java.sql.Date sqlDate11=new java.sql.Date(date11.getTime());
					 Map<Long, Long>accountsList=new HashMap<>();
					System.out.println("===============================");;
					
					 bal=bal-money;

					 try(Connection connection1=DBConnection.getConnection();) {
							statement=connection1.prepareStatement("select accountNo from accounts ");
					
					ResultSet	rs1=statement.executeQuery();
		
				while(rs1.next()) {
					
				
			
					if(accno==rs1.getLong(1)) {
						flag2=true;
						break;
					}

				}
	
					if(flag2) {
					System.out.println("from account:"+accountNo+"    to aacountNo:"+accno);
						 Transaction tran2=new  Transaction(accountNo,accno,sqlDate11,"Debit",money,Tid);
						 boolean flag111=service.addTransaction(tran2,bal);
						 boolean flag22=service.transferTo(tran2,money);
				
							if(flag111)
								System.out.println("  Money Transferred Successfully..................... ");
							else
								System.out.println("unable to create account");
						
					}
					 }
					 break;
				case 5:
					   System.out.println("printing transaction");
				      HashMap<Integer, Transaction>hs=service.getTransaction();
				      Iterator<Transaction>it=hs.values().iterator();
				      System.out.println("TransactionID        From Account           To Account         Date        TransactionType         Amount");
				      System.out.println("---------------------------------------------------------------------------------------");
				      
						 try(Connection connection1=DBConnection.getConnection();) {
								statement=connection1.prepareStatement("select tid,from_acc_no,to_acc_no,dt,type,AMOUNT from transaction ");
						
						ResultSet	rs1=statement.executeQuery();
						
						while(rs1.next()) {
						
					
						
						if(accountNo==rs1.getLong(2)||accountNo==rs1.getLong(3)) {
							System.out.println(rs1.getInt(1)+"                       "+rs1.getLong(2)+"                "+rs1.getLong(3)+"          "+rs1.getDate(4)+"      "+rs1.getString(5)+"                        "+rs1.getLong(6));
					
						}
					}
						 }

					
				      break;
						
					 
				case 0:System.out.println("***********************Come back Soon..!!********************************");
					System.exit(0);
				default:
					System.out.println("Please enter the  Correct Choice ");
					flag=true;

				}
				System.out.println("Press Y to continue");
				Scanner scan=new Scanner(System.in);
				ch = scan.nextLine();
				
				
			} catch (InputMismatchException e) {
				System.err.println("Please enter 1 or 0 only");
			}
	        }while(ch.equalsIgnoreCase("y"));
			
			
			
			
		}
else {
	System.out.println("invalid credentials");
}
		}
}
		
	
	private void Register() throws SQLException {
		
		boolean flag=true;
		do {
			scanner=new Scanner(System.in);
			System.out.println("enter Name");
			uname=scanner.nextLine();
			try {
				flag=service.isNameValid(uname);
				
				if(flag)
					throw new BankApplicationException();
			}catch(BankApplicationException e) {
				System.err.println("first letter in the name should be capital throws");
			}
			
		}while(flag);

		do {
			scanner=new Scanner(System.in);
			System.out.println("set Password");
			password=scanner.nextLine();
			try {
				flag=service.isPasswordValid(password);
				
				if(flag)
					throw new BankApplicationException();
			}catch(BankApplicationException e) {
				System.err.println("use numbers and alphabets only");
			}
			
		}while(flag);		
		
		do {
			scanner=new Scanner(System.in);
			System.out.println("enter address");
			address=scanner.nextLine();
			try {
				flag=service.isAddressValid(address);
				
				if(flag)
					throw new BankApplicationException();
			}catch(BankApplicationException e) {
				System.err.println("use numbers and alphabets only");
			}
			
		}while(flag);

		do {
			scanner=new Scanner(System.in);
			System.out.println("enter mobile number");
			mobileNo=scanner.nextLine();
			try {
				flag=service.isMobileValid(mobileNo);
				
				if(flag)
					throw new BankApplicationException();
			}catch(BankApplicationException e) {
				System.err.println("enters numbers only");
			}
			
		}while(flag);
		
		do {
			scanner=new Scanner(System.in);
			System.out.println("enter aadhar number");
			aadhrCardNo=scanner.nextLong();
			try {
				flag=service.isAadharValid(aadhrCardNo);
				
				if(flag)
					throw new BankApplicationException();
			}catch(BankApplicationException e) {
				System.err.println("enters numbers only");
			}
			
		}while(flag);
		
		accountNo=(long)(Math.random()*1000000000);
	
		Account account=new Account(uname,password,address,mobileNo,aadhrCardNo,0,accountNo);

		boolean flag1=service.addAccount(account);
		if(flag1) {
			System.out.println("  account created successfully");
			System.out.println("enter login details to access your account");
		
		}
		else
			System.out.println("unable to create account");
		Login(accountNo);
	}

	public static void main(String[] args) throws SQLException {
		UIClass clientUI = new UIClass();
		Scanner scanner=new Scanner(System.in);
		java.util.Date date=new java.util.Date();
		
		java.sql.Date sqlDate=new java.sql.Date(date.getTime());
		 System.out.println("Date:"+date);
		System.out.println("--------------------Welcome to the Capgemini Bank-------------------------------");
		int choice = 2;
		boolean flag = true;
		String ch = null;
        do {
		System.out.println(" 1.Register \n 0.Exit");
		try {
			Scanner scanner1=new Scanner(System.in);
			choice = scanner1.nextInt();

			switch (choice) {
			case 1:
				clientUI.Register();
				flag=false;
				break;
			case 2:
			
				break;
			
			case 0:System.out.println("Come back Soon..!!");
				System.exit(0);
			default:
				System.out.println("Please enter the  Correct Choice ");
				flag=true;

			}
			System.out.println("Press Y to continue");
			Scanner scan=new Scanner(System.in);
			ch = scan.nextLine();
			
			
			
		} catch (InputMismatchException e) {
			System.err.println("Please enter correct only");
		}
        }while(ch.equalsIgnoreCase("y"));

	}

	

	
}
