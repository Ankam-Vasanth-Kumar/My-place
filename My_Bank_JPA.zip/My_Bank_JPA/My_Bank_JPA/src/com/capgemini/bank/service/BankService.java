package com.capgemini.bank.service;

import java.util.HashMap;


import com.capgemini.bank.bean.Accounts;
import com.capgemini.bank.bean.Transaction;

public interface BankService {

	
	boolean isNameValid(String uname);

	boolean isPasswordValid(String password);

	boolean isAddressValid(String address);

	boolean isMobileValid(String mobileNo);

	boolean isAadharValid(long aadhrCardNo);

	boolean addAccount(Accounts account);

	HashMap<Long, Accounts> getAccountDetails();

	HashMap<String, String> getUnamePassword();

	void ShowBalance(long accountNo);

	boolean addTransaction(Transaction tran, double amount);
	HashMap<Integer, Transaction> getTransaction(long accountNo);

	boolean transferTo(long accno, long money);

	void deposite(long accountNo, double amount);

	void withdraw(long accountNo, double amount);

	boolean checkLogin(String name, String password2);

}
