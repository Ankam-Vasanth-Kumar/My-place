package com.capgemini.BankingSystem.Service;

import java.util.List;

import com.capgemin.BankingSystem.Bean.Transactions;
import com.capgemini.BankingSystem.Exception.BankingException;

public interface IBankingService {
	int addTransact(Transactions tran);
	public int accountNo();
	public double balance();
	public List<Transactions> printAllTransactions();
	
	public boolean isPhonevalid(String phone)throws BankingException;
	public boolean isNamevalid(String name)throws BankingException;
	public boolean narration(String string, double amount);
	boolean isAadhaarvalid(String name) throws BankingException;
   
}
