package com.capgemini.BankingSystem.Utility;

import java.util.HashMap;
import java.util.Map;

import com.capgemin.BankingSystem.Bean.Transactions;

public class BankingRepository {
	 public static Map<Integer,Transactions> transList=new HashMap<>();
	 static {
		 transList.put(111,new Transactions(111,1000,2000,"2019-07-11","Credit"));
		 transList.put(222,new Transactions(222,1000,1000,"2019-07-11","Debit"));
		 transList.put(333,new Transactions(333,1000,2000,"2019-07-11","Credit"));
		 
	 }
	public Map<Integer, Transactions> getTransList() {
		return transList;
	}
	public static void setTransList(Map<Integer, Transactions> transList) {
		BankingRepository.transList = transList;
	}
	 
	 

}
