package com.cg.bank.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {
	private String name;
	private String email;
	private String mobile;
	private double amount;
	private int password;
	private String address;
	@Id
	private long accountNo;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(String name, String email, String mobile, double amount,long accountNo, int password, String address) {
		super();
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.amount = amount;
		this.password = password;
		this.accountNo = accountNo;
		this.address=address;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getPassword() {
		return password;
	}
	public void setPassword(int password) {
		this.password = password;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	

}
