package com.cg.bank.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class BankTransaction {
	@Id
	private int transacId;
	private long toAccNo;
	private long fromAccNo;
	private String TransacType;
	@Column(name="date1")
	private Date date;
	private double amount;
	private double balance;
	
	public BankTransaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BankTransaction(int transacId, long toAccNo, long fromAccNo, String transacType, Date date, double amount,
			double balance) {
		super();
		this.transacId = transacId;
		this.toAccNo = toAccNo;
		this.fromAccNo = fromAccNo;
		TransacType = transacType;
		this.date = date;
		this.amount = amount;
		this.balance = balance;
	}
	public int getTransacId() {
		return transacId;
	}
	public void setTransacId(int transacId) {
		this.transacId = transacId;
	}
	public long getToAccNo() {
		return toAccNo;
	}
	public void setToAccNo(long toAccNo) {
		this.toAccNo = toAccNo;
	}
	public long getFromAccNo() {
		return fromAccNo;
	}
	public void setFromAccNo(long fromAccNo) {
		this.fromAccNo = fromAccNo;
	}
	public String getTransacType() {
		return TransacType;
	}
	public void setTransacType(String transacType) {
		TransacType = transacType;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Transaction1 [transacId=" + transacId + ", toAccNo=" + toAccNo + ", fromAccNo=" + fromAccNo
				+ ", TransacType=" + TransacType + ", date=" + date + ", amount=" + amount + ", balance=" + balance
				+ "]";
	}

}
