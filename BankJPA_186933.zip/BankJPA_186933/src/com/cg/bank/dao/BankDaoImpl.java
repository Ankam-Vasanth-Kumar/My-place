package com.cg.bank.dao;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.BankTransaction;
import com.cg.bank.bean.Customer;


import com.cg.bank.exception.BankException;

public class BankDaoImpl implements BankDao {
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");

	EntityManager entityManager = factory.createEntityManager();

	@Override
	public boolean addCustomer(Customer customer) throws BankException {
		entityManager.getTransaction().begin();
		entityManager.persist(customer);
		entityManager.getTransaction().commit();

		return true;
	}

	@Override
	public boolean addAccount(Account account) throws BankException {
		entityManager.getTransaction().begin();
		entityManager.persist(account);
		entityManager.getTransaction().commit();
		return true;
	}

	@Override
	public Account validateLogin(String userName, int password) throws BankException {
		TypedQuery<Account> querry = (TypedQuery<Account>) entityManager.createQuery("from Account", Account.class);
		List<Account> acclist = querry.getResultList();
		for (Account acnt : acclist) {

			if (acnt.getName().equals(userName) && acnt.getPassword() == password) {

				return acnt;
			}

		}
		return null;
	}

	@Override
	public boolean withdraw(double withDraw, Account account) throws BankException {

		Date date = new Date();
		java.sql.Date d1 = new java.sql.Date(date.getTime());
		int transaId = getTransId();

		TypedQuery<Account> querry = (TypedQuery<Account>) entityManager.createQuery("from Account ", Account.class);
		entityManager.getTransaction().begin();
		entityManager.clear();
		List<Account> amt = querry.getResultList();
		Iterator<Account> iterator = amt.iterator();
		while (iterator.hasNext()) {
			Account acc = iterator.next();
			if ((acc.getAccountNo() == account.getAccountNo())) {
				if (acc.getAmount() > withDraw) {
					double amount = acc.getAmount() - withDraw;
					acc.setAmount(amount);
					account.setAmount(amount);
					entityManager.persist(acc);
					entityManager.getTransaction().commit();
					return true;
				} else {
					throw new BankException("Insufficient fund");
				}
			}
		}
		entityManager.getTransaction().commit();
		
		
		entityManager.persist(account);
		entityManager.getTransaction().commit();
		return false;

	}

	@Override
	public boolean depositAmount(double depositAmount, Account account) throws BankException {
		entityManager.getTransaction().begin();
		
		TypedQuery<Account> querry = (TypedQuery<Account>) entityManager.createQuery("from Account ", Account.class);
		List<Account> amt = querry.getResultList();
		Iterator<Account> iterator = amt.iterator();
		while (iterator.hasNext()) {
			Account acc = iterator.next();
			if ((acc.getAccountNo() == account.getAccountNo())) {

				double amount = acc.getAmount() + depositAmount;

				acc.setAmount(amount);
				account.setAmount(amount);
				entityManager.persist(acc);
				entityManager.getTransaction().commit();
				return true;
			}

		}

		entityManager.persist(account);
		entityManager.getTransaction().commit();

		return false;
	}

	@Override
	public double getBalance(Account account) throws BankException {
		double amount = account.getAmount();
		return amount;
	}


	@Override
	public boolean printTransactions(Account account) throws BankException {

		TypedQuery<BankTransaction> querry = (TypedQuery<BankTransaction>) entityManager.createQuery("from BankTransaction ",
				BankTransaction.class);
		List<BankTransaction> amt = querry.getResultList();
		Iterator<BankTransaction> iterator = amt.iterator();
		while (iterator.hasNext()) {
			BankTransaction transaction = iterator.next();
			if (transaction.getFromAccNo() == account.getAccountNo()) {
				System.out.println(transaction);

			}
		}

		return true;
	}

	@Override
	public int getTransId() throws BankException {
		Random r =new Random();
		int transId=r.nextInt();
		return transId;
		
	}

	@Override
	public boolean addTransaction(BankTransaction transaction) throws BankException {
		
		entityManager.getTransaction().begin();
		entityManager.clear();
		entityManager.persist(transaction);
		entityManager.getTransaction().commit();

	
		return true;
	}

}
