package com.cg.bank.dao;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.BankTransaction;
import com.cg.bank.bean.Customer;
import com.cg.bank.exception.BankException;

public interface BankDao {

	boolean addCustomer(Customer customer)throws BankException;

	boolean addAccount(Account account)throws BankException;

	Account validateLogin(String userName, int password)throws BankException;

	boolean withdraw(double withDraw,Account account)throws BankException;

	boolean depositAmount(double depositAmount,Account account)throws BankException;

	double getBalance(Account account)throws BankException;

	boolean printTransactions(Account account)throws BankException;
	int getTransId()throws BankException;

	boolean addTransaction(BankTransaction transaction)throws BankException;

}
