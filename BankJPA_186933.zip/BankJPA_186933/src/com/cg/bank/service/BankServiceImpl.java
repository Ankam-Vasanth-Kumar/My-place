package com.cg.bank.service;

import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.BankTransaction;
import com.cg.bank.bean.Customer;
import com.cg.bank.dao.BankDao;
import com.cg.bank.dao.BankDaoImpl;
import com.cg.bank.exception.BankException;

import oracle.net.aso.p;

public class BankServiceImpl implements BankService {
	private BankDao bankDao= new BankDaoImpl();

	@Override
	public boolean validateName(String name) throws BankException {
		boolean status = false;

		Pattern pattern = Pattern.compile("^[A-Z]{1}[a-z]{1,}$");
		Matcher match = pattern.matcher(name);
		if (match.matches()) {
			status = true;

		} else {
			throw new BankException("Name must start with capital letter");
		}
		return status;
	}

	@Override
	public boolean validateEmail(String email) throws BankException {
		boolean status = false;

		Pattern pattern = Pattern.compile("^[A-Za-z0-9]{4,}@gmail.com$");
		Matcher match = pattern.matcher(email);
		if (match.matches()) {
			status = true;

		} else {
			throw new BankException("Invalid email");
		}
		return status;
	}

	@Override
	public boolean validateMobile(String mobile) throws BankException {
		boolean status = false;

		Pattern pattern = Pattern.compile("^[7-9]{1}[0-9]{9}$");
		Matcher match = pattern.matcher(mobile);
		if (match.matches()) {
			status = true;

		} else {
			throw new BankException("Invalid Phone");
		}
		return status;
	}

	@Override
	public long getAccountNo() throws BankException {
		Random r =new Random();
		long accountNo=r.nextInt((100000-50000)+1)+50000;
		return accountNo;
	}

	@Override
	public boolean validateAmount(double amount) throws BankException {
		boolean status = false;

		
		if (amount>=5000) {
			status = true;

		} else {
			throw new BankException("Minimum balance should be 5000");
		}
		return status;
	}

	@Override
	public int getPassword() throws BankException {
		Random r =new Random();
		int password=r.nextInt((10000-5000)+1)+50000;
		return password;
	}

	@Override
	public boolean addCustomer(Customer customer) throws BankException {
		// TODO Auto-generated method stub
		return bankDao.addCustomer(customer);
	}

	@Override
	public boolean addAcount(Account account) throws BankException {
		// TODO Auto-generated method stub
		return bankDao.addAccount(account);
	}

	@Override
	public Account validateLogin(String userName, int password) throws BankException {
		// TODO Auto-generated method stub
		return bankDao.validateLogin(userName,password);
	}

	@Override
	public boolean withdraw(double withDraw,Account account) throws BankException {
		// TODO Auto-generated method stub
		return bankDao.withdraw(withDraw,account);
	}

	@Override
	public boolean deposit(double depositAmount,Account account) throws BankException {
		// TODO Auto-generated method stub
		return bankDao.depositAmount(depositAmount,account);
	}

	@Override
	public double getBalance(Account account) throws BankException {
		// TODO Auto-generated method stub
		return bankDao.getBalance(account);
	}

	@Override
	public boolean printTransactions(Account account) throws BankException {
		// TODO Auto-generated method stub
		return bankDao.printTransactions(account);
	}

	@Override
	public int getTransId() throws BankException {
		// TODO Auto-generated method stub
		return bankDao.getTransId();
	}

	@Override
	public boolean addTransaction(BankTransaction transaction) throws BankException {
		// TODO Auto-generated method stub
		return bankDao.addTransaction(transaction);
	}

}
