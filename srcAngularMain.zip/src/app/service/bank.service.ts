import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Customer } from '../bean/customer';
import { Account } from '../bean/account';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BankService {
  a
  private userUrl = 'http://localhost:5200';
  constructor(private http: HttpClient) { }
  public addCustomer(customer:Customer):Observable<Customer>{
    return this.http.post<Customer>(this.userUrl+'/addCustomer',customer);
  }
  public showBalance(acc:number) {
    console.log(acc);
    return this.http.get<Account>(this.userUrl+'/login/showbalance/'+acc);
     }
     public deposit(acc:number,cust:Account):Observable<Account>
{
return this.http.put<Account>(this.userUrl+'/login/deposit/'+acc,cust);
}

}
